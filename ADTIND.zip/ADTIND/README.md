

Installation
============

Compiles with gcc (on Linux) and clang (on Mac). Assumes preinstalled Gmp and Boost packages.

* `mkdir build ; cd build`
* `cmake ../`
* `make` to build dependencies (Z3 and LLVM)
* `make` to build AdtInd

The binary of AdtInd can be found in `build/tools/adt/ind`.

Benchmarks
==========

use `run-all.py` to run available benchmarks in `bench_adt/`
